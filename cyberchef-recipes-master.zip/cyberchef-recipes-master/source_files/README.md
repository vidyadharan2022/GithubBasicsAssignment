## Source files 

All files have been zipped with password: `infected`. There may be another zip inside, probably `infected` again!